import{W as n}from"./vendor.f6054781.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
