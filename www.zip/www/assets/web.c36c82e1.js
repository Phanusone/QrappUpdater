import{W as n}from"./vendor.71f7eb31.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
