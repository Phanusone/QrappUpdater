import{W as n}from"./vendor.131e8e96.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
