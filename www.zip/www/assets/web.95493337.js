import{W as n}from"./vendor.dd638d12.js";class o extends n{async show(e){}async hide(e){}}export{o as SplashScreenWeb};
