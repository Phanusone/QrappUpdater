import{W as n}from"./vendor.d9896605.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
